# HireSense AI Synthetic Dataset Pack

This pack contains generated synthetic data for learning and testing HireSense AI. It does not contain real people or real resumes.

## Files
- `hiresense_500_synthetic_resumes.csv`: 500 synthetic candidate profiles with resume text, skills, education, experience, projects, certifications, location, and target role.
- `hiresense_50_job_descriptions.csv`: 50 synthetic job descriptions with required/preferred skills and metadata.
- `hiresense_500_resume_job_pairs.csv`: 500 synthetic candidate-job pairs with skills, overlap ratio, and a heuristic match label.

## Important limitations
- All records are synthetic and generated for software testing, not representative of the labor market.
- Match labels are heuristics based on skill overlap and role pairing, not expert hiring judgments.
- Do not use this dataset to make real hiring decisions or claim model performance on real candidates.
- `location` is a fictional preference field and should not be used as a ranking feature.
